javac *.java
#java Chess 3 5